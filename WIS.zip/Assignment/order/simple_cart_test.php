<?php
require_once '../_base.php';

// Check if user is logged in
if (!isLoggedIn()) {
    die('Please log in to test cart functionality');
}

$userID = $_SESSION['user_id'];

echo "<h2>Simple Cart Test</h2>";

try {
    // Get user's cart
    $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
    $cartStmt = $_db->prepare($cartQuery);
    $cartStmt->execute([$userID]);
    $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cart) {
        echo "<p style='color: red;'>No cart found for user ID: $userID</p>";
        exit();
    }
    
    $cartID = $cart['cartID'];
    echo "<p>Cart ID: $cartID</p>";
    
    // Get cart items
    $itemsQuery = "SELECT ci.*, p.name, p.price, p.qty as stock
                  FROM cart_items ci
                  JOIN product p ON ci.prodID = p.prodID
                  WHERE ci.cartID = ? AND (p.status IS NULL OR p.status != 'removed')";
    $itemsStmt = $_db->prepare($itemsQuery);
    $itemsStmt->execute([$cartID]);
    $cart_items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Current Cart Items:</h3>";
    if (empty($cart_items)) {
        echo "<p>No items in cart</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Stock</th><th>Test</th></tr>";
        
        foreach ($cart_items as $item) {
            echo "<tr>";
            echo "<td>{$item['prodID']}</td>";
            echo "<td>{$item['name']}</td>";
            echo "<td>{$item['qty']}</td>";
            echo "<td>RM " . number_format($item['price'], 2) . "</td>";
            echo "<td>{$item['stock']}</td>";
            echo "<td>";
            echo "<button onclick='testUpdate(\"{$item['prodID']}\", {$item['qty']})'>Test Update</button>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<h3>Test Results:</h3>";
    echo "<div id='test-results'></div>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>

<script>
function testUpdate(prodID, currentQty) {
    const newQty = currentQty + 1;
    const resultsDiv = document.getElementById('test-results');
    
    resultsDiv.innerHTML = '<p>Testing update for Product ID: ' + prodID + ', New Quantity: ' + newQty + '</p>';
    resultsDiv.innerHTML += '<p>Request details: action=update, prodID=' + prodID + ', qty=' + newQty + '</p>';
    
    // Test 1: Direct AJAX to cart_page.php
    testCartPage(prodID, newQty, resultsDiv);
}

function testCartPage(prodID, qty, resultsDiv) {
    resultsDiv.innerHTML += '<p><strong>Test 1: cart_page.php</strong></p>';
    
    const formData = new FormData();
    formData.append('ajax', '1');
    formData.append('action', 'update');
    formData.append('prodID', prodID);
    formData.append('qty', qty);
    
    fetch('cart_page.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        resultsDiv.innerHTML += '<p>Response status: ' + response.status + ' ' + response.statusText + '</p>';
        resultsDiv.innerHTML += '<p>Response headers: ' + JSON.stringify([...response.headers.entries()]) + '</p>';
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return response.text();
    })
    .then(text => {
        resultsDiv.innerHTML += '<p>Raw response length: ' + text.length + '</p>';
        resultsDiv.innerHTML += '<p>Raw response (first 500 chars): ' + text.substring(0, 500) + '</p>';
        
        try {
            const data = JSON.parse(text);
            resultsDiv.innerHTML += '<p style="color: green;">✅ JSON Parse Success</p>';
            resultsDiv.innerHTML += '<p>Parsed data: ' + JSON.stringify(data, null, 2) + '</p>';
            
            if (data.success) {
                resultsDiv.innerHTML += '<p style="color: green;">✅ SUCCESS: ' + data.message + '</p>';
            } else {
                resultsDiv.innerHTML += '<p style="color: red;">❌ FAILED: ' + data.message + '</p>';
            }
        } catch (e) {
            resultsDiv.innerHTML += '<p style="color: red;">❌ JSON Parse Error: ' + e.message + '</p>';
            resultsDiv.innerHTML += '<p>This suggests the server is returning HTML instead of JSON</p>';
        }
    })
    .catch(error => {
        resultsDiv.innerHTML += '<p style="color: red;">❌ Fetch Error: ' + error.message + '</p>';
        resultsDiv.innerHTML += '<p>Error type: ' + error.constructor.name + '</p>';
    });
}
</script>

<style>
table {
    margin: 20px 0;
}
th, td {
    padding: 8px;
    text-align: left;
}
button {
    padding: 5px 10px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
button:hover {
    background: #0056b3;
}
#test-results {
    background: #f8f9fa;
    padding: 15px;
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin: 10px 0;
    font-family: monospace;
    font-size: 12px;
}
</style>
