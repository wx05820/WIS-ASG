<?php
require_once '../_base.php';

// Check if user is logged in
if (!isLoggedIn()) {
    die('Please log in to test cart functionality');
}

$userID = $_SESSION['user_id'];

echo "<h2>Cart Update Debug</h2>";

try {
    // Get user's cart
    $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
    $cartStmt = $_db->prepare($cartQuery);
    $cartStmt->execute([$userID]);
    $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cart) {
        echo "<p style='color: red;'>No cart found for user ID: $userID</p>";
        exit();
    }
    
    $cartID = $cart['cartID'];
    echo "<p>Cart ID: $cartID</p>";
    
    // Get cart items
    $itemsQuery = "SELECT ci.*, p.name, p.price, p.qty as stock
                  FROM cart_items ci
                  JOIN product p ON ci.prodID = p.prodID
                  WHERE ci.cartID = ? AND (p.status IS NULL OR p.status != 'removed')";
    $itemsStmt = $_db->prepare($itemsQuery);
    $itemsStmt->execute([$cartID]);
    $cart_items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Current Cart Items:</h3>";
    if (empty($cart_items)) {
        echo "<p>No items in cart</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Stock</th><th>Test Update</th></tr>";
        
        foreach ($cart_items as $item) {
            echo "<tr>";
            echo "<td>{$item['prodID']} (" . gettype($item['prodID']) . ")</td>";
            echo "<td>{$item['name']}</td>";
            echo "<td>{$item['qty']}</td>";
            echo "<td>RM " . number_format($item['price'], 2) . "</td>";
            echo "<td>{$item['stock']}</td>";
            echo "<td>";
            echo "<button onclick='testUpdate(\"{$item['prodID']}\", {$item['qty']})'>Test +1</button>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<h3>Test Results:</h3>";
    echo "<div id='test-results'></div>";
    
    // Test direct database update
    if (!empty($cart_items)) {
        $testItem = $cart_items[0];
        $testProdID = $testItem['prodID'];
        $testQty = $testItem['qty'] + 1;
        
        echo "<h3>Direct Database Test:</h3>";
        echo "<p>Testing direct update for Product ID: $testProdID, New Quantity: $testQty</p>";
        
        try {
            $updateQuery = "UPDATE cart_items SET qty = ? WHERE cartID = ? AND prodID = ?";
            $updateStmt = $_db->prepare($updateQuery);
            $result = $updateStmt->execute([$testQty, $cartID, $testProdID]);
            $rowCount = $updateStmt->rowCount();
            
            echo "<p>Update result: " . ($result ? 'Success' : 'Failed') . "</p>";
            echo "<p>Rows affected: $rowCount</p>";
            
            if ($rowCount > 0) {
                echo "<p style='color: green;'>✅ Direct database update successful!</p>";
                
                // Revert the change
                $revertQuery = "UPDATE cart_items SET qty = ? WHERE cartID = ? AND prodID = ?";
                $revertStmt = $_db->prepare($revertQuery);
                $revertStmt->execute([$testItem['qty'], $cartID, $testProdID]);
                echo "<p>Reverted quantity back to {$testItem['qty']}</p>";
            } else {
                echo "<p style='color: red;'>❌ Direct database update failed - no rows affected</p>";
            }
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Direct database update error: " . $e->getMessage() . "</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>

<script>
function testUpdate(prodID, currentQty) {
    const newQty = currentQty + 1;
    const resultsDiv = document.getElementById('test-results');
    
    resultsDiv.innerHTML = '<p>Testing AJAX update for Product ID: ' + prodID + ', New Quantity: ' + newQty + '</p>';
    
    const formData = new FormData();
    formData.append('ajax', '1');
    formData.append('action', 'update');
    formData.append('prodID', prodID);
    formData.append('qty', newQty);
    
    fetch('cart_page.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        console.log('Response status:', response.status);
        return response.text();
    })
    .then(text => {
        console.log('Raw response:', text);
        try {
            const data = JSON.parse(text);
            console.log('Parsed data:', data);
            
            if (data.success) {
                resultsDiv.innerHTML += '<p style="color: green;">✅ AJAX SUCCESS: ' + data.message + '</p>';
                resultsDiv.innerHTML += '<p>Updated cart data: ' + JSON.stringify(data.data, null, 2) + '</p>';
            } else {
                resultsDiv.innerHTML += '<p style="color: red;">❌ AJAX FAILED: ' + data.message + '</p>';
            }
        } catch (e) {
            console.error('JSON parse error:', e);
            resultsDiv.innerHTML += '<p style="color: red;">❌ JSON Parse Error: ' + e.message + '</p>';
            resultsDiv.innerHTML += '<p>Raw response: ' + text + '</p>';
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        resultsDiv.innerHTML += '<p style="color: red;">❌ Fetch Error: ' + error.message + '</p>';
    });
}
</script>

<style>
table {
    margin: 20px 0;
}
th, td {
    padding: 8px;
    text-align: left;
}
button {
    padding: 5px 10px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
button:hover {
    background: #0056b3;
}
</style>
