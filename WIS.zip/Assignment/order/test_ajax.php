<?php
// Simple test endpoint for AJAX
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test'])) {
    echo json_encode([
        'success' => true,
        'message' => 'AJAX test successful',
        'data' => [
            'timestamp' => date('Y-m-d H:i:s'),
            'post_data' => $_POST
        ]
    ]);
    exit();
}

echo json_encode([
    'success' => false,
    'message' => 'Invalid request'
]);
?>

