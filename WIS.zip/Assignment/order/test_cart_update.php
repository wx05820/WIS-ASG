<?php
// Test cart update functionality
require_once '../_base.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'User not logged in'
    ]);
    exit();
}

$userID = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_cart'])) {
    try {
        // Get user's cart
        $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
        $cartStmt = $_db->prepare($cartQuery);
        $cartStmt->execute([$userID]);
        $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$cart) {
            echo json_encode([
                'success' => false,
                'message' => 'Cart not found for user'
            ]);
            exit();
        }
        
        $cartID = $cart['cartID'];
        
        // Get cart items
        $itemsQuery = "SELECT ci.*, p.name, p.price FROM cart_items ci 
                      JOIN product p ON ci.prodID = p.prodID 
                      WHERE ci.cartID = ? 
                      LIMIT 1";
        $itemsStmt = $_db->prepare($itemsQuery);
        $itemsStmt->execute([$cartID]);
        $item = $itemsStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$item) {
            echo json_encode([
                'success' => false,
                'message' => 'No items found in cart'
            ]);
            exit();
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Cart data retrieved successfully',
            'data' => [
                'cartID' => $cartID,
                'userID' => $userID,
                'item' => $item,
                'test_update' => [
                    'prodID' => $item['prodID'],
                    'current_qty' => $item['qty'],
                    'new_qty' => $item['qty'] + 1
                ]
            ]
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error: ' . $e->getMessage()
        ]);
    }
    exit();
}

echo json_encode([
    'success' => false,
    'message' => 'Invalid request'
]);
?>

