<?php
require_once '../_base.php';

// Set JSON header
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'Please log in to manage your cart',
        'redirect' => '../user/login.php'
    ]);
    exit();
}

$userID = $_SESSION['user_id'];

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $prodID = trim($_POST['prodID'] ?? '');
    $qty = intval($_POST['qty'] ?? 1);
    
    try {
        // Get user's cart
        $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
        $cartStmt = $_db->prepare($cartQuery);
        $cartStmt->execute([$userID]);
        $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$cart) {
            throw new Exception("Cart not found");
        }
        
        $cartID = $cart['cartID'];
        
        switch ($action) {
            case 'update':
                if (!empty($prodID) && $qty > 0) {
                    // Check stock availability
                    $stockQuery = "SELECT qty FROM product WHERE prodID = ? AND (status IS NULL OR status != 'removed')";
                    $stockStmt = $_db->prepare($stockQuery);
                    $stockStmt->execute([$prodID]);
                    $stock = $stockStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$stock) {
                        throw new Exception("Product not found or unavailable");
                    }
                    
                    if ($qty > $stock['qty']) {
                        throw new Exception("Insufficient stock. Available: " . $stock['qty']);
                    }
                    
                    // Update quantity
                    $updateQuery = "UPDATE cart_items SET qty = ? WHERE cartID = ? AND prodID = ?";
                    $updateStmt = $_db->prepare($updateQuery);
                    $updateStmt->execute([$qty, $cartID, $prodID]);
                    
                    if ($updateStmt->rowCount() > 0) {
                        $message = "Quantity updated successfully";
                    } else {
                        throw new Exception("Item not found in cart");
                    }
                } else {
                    throw new Exception("Invalid product ID or quantity");
                }
                break;
                
            case 'remove':
                if (!empty($prodID)) {
                    $removeQuery = "DELETE FROM cart_items WHERE cartID = ? AND prodID = ?";
                    $removeStmt = $_db->prepare($removeQuery);
                    $removeStmt->execute([$cartID, $prodID]);
                    
                    if ($removeStmt->rowCount() > 0) {
                        $message = "Item removed from cart";
                    } else {
                        throw new Exception("Item not found in cart");
                    }
                } else {
                    throw new Exception("Invalid product ID");
                }
                break;
                
            case 'clear':
                $clearQuery = "DELETE FROM cart_items WHERE cartID = ?";
                $clearStmt = $_db->prepare($clearQuery);
                $clearStmt->execute([$cartID]);
                $message = "Cart cleared successfully";
                break;
                
            default:
                throw new Exception("Invalid action");
        }
        
        // Get updated cart data
        $cartData = getCartData($cartID);
        
        // Update cart count in session
        $_SESSION['cart_count'] = $cartData['total_items'];
        
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $cartData
        ]);
        
    } catch (Exception $e) {
        error_log("Cart AJAX error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}

function getCartData($cartID) {
    global $_db;
    
    try {
        // Get cart items with product details
        $itemsQuery = "SELECT ci.*, p.name, p.price, p.qty as stock, p.image1, p.color, p.material
                      FROM cart_items ci
                      JOIN product p ON ci.prodID = p.prodID
                      WHERE ci.cartID = ? AND (p.status IS NULL OR p.status != 'removed')";
        $itemsStmt = $_db->prepare($itemsQuery);
        $itemsStmt->execute([$cartID]);
        $cart_items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $subtotal = 0;
        $total_items = 0;
        
        // Calculate totals
        foreach ($cart_items as $item) {
            $item_subtotal = ($item['price'] ?? 0) * ($item['qty'] ?? 0);
            $subtotal += $item_subtotal;
            $total_items += ($item['qty'] ?? 0);
        }
        
        $shipping_fee = 8.00;
        $total = $subtotal + $shipping_fee;
        
        return [
            'items' => $cart_items,
            'subtotal' => $subtotal,
            'shipping_fee' => $shipping_fee,
            'total' => $total,
            'total_items' => $total_items
        ];
        
    } catch (Exception $e) {
        error_log("Get cart data error: " . $e->getMessage());
        return [
            'items' => [],
            'subtotal' => 0,
            'shipping_fee' => 8.00,
            'total' => 8.00,
            'total_items' => 0
        ];
    }
}
?>

