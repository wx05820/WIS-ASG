<?php
require_once '../_base.php';

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['error'] = "Please log in to view your cart";
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header('Location: ../user/login.php');
    exit();
}

$userID = $_SESSION['user_id'];

// Handle AJAX cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    // Start output buffering to prevent any output before JSON
    ob_start();
    
    // Set JSON header for AJAX requests
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    $prodID = trim($_POST['prodID'] ?? '');
    $qty = intval($_POST['qty'] ?? 1);
    
    // Debug logging
    error_log("Cart AJAX Request - Action: $action, ProdID: $prodID (type: " . gettype($prodID) . "), Qty: $qty");
    
    // Validate required parameters
    if (empty($action)) {
        ob_clean(); // Clear any output before JSON
        echo json_encode([
            'success' => false,
            'message' => 'Action parameter is required'
        ]);
        exit();
    }
    
    if ($action === 'update' && (empty($prodID) || $qty < 1)) {
        ob_clean(); // Clear any output before JSON
        echo json_encode([
            'success' => false,
            'message' => 'Product ID and quantity are required for update action'
        ]);
        exit();
    }
    
    try {
        // Get user's cart
        $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
        $cartStmt = $_db->prepare($cartQuery);
        $cartStmt->execute([$userID]);
        $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$cart) {
            throw new Exception("Cart not found");
        }
        
        $cartID = $cart['cartID'];
        
        switch ($action) {
            case 'update':
                if (!empty($prodID) && $qty > 0) {
                    // Check stock availability
                    $stockQuery = "SELECT qty FROM product WHERE prodID = ? AND (status IS NULL OR status != 'removed')";
                    $stockStmt = $_db->prepare($stockQuery);
                    $stockStmt->execute([$prodID]);
                    $stock = $stockStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$stock) {
                        throw new Exception("Product not found or unavailable");
                    }
                    
                    if ($qty > $stock['qty']) {
                        throw new Exception("Insufficient stock. Available: " . $stock['qty'] . " items");
                    }
                    
                    // Debug: Check what's actually in the cart
                    $debugQuery = "SELECT prodID, qty FROM cart_items WHERE cartID = ?";
                    $debugStmt = $_db->prepare($debugQuery);
                    $debugStmt->execute([$cartID]);
                    $cartItems = $debugStmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    error_log("Debug - Cart items: " . print_r($cartItems, true));
                    error_log("Debug - Trying to update prodID: $prodID, qty: $qty, cartID: $cartID");
                    
                    // Update quantity
                    $updateQuery = "UPDATE cart_items SET qty = ? WHERE cartID = ? AND prodID = ?";
                    $updateStmt = $_db->prepare($updateQuery);
                    $updateStmt->execute([$qty, $cartID, $prodID]);
                    
                    if ($updateStmt->rowCount() > 0) {
                        $message = "Quantity updated successfully";
                    } else {
                        throw new Exception("Item not found in cart. Available items: " . implode(', ', array_column($cartItems, 'prodID')));
                    }
                } else {
                    throw new Exception("Invalid product ID or quantity");
                }
                break;
                
            case 'remove':
                if (!empty($prodID)) {
                    $removeQuery = "DELETE FROM cart_items WHERE cartID = ? AND prodID = ?";
                    $removeStmt = $_db->prepare($removeQuery);
                    $removeStmt->execute([$cartID, $prodID]);
                    
                    if ($removeStmt->rowCount() > 0) {
                        $message = "Item removed from cart";
                    } else {
                        throw new Exception("Item not found in cart");
                    }
                } else {
                    throw new Exception("Invalid product ID");
                }
                break;
                
            case 'clear':
                $clearQuery = "DELETE FROM cart_items WHERE cartID = ?";
                $clearStmt = $_db->prepare($clearQuery);
                $clearStmt->execute([$cartID]);
                $message = "Cart cleared successfully";
                break;
                
            default:
                throw new Exception("Invalid action");
        }
        
        // Get updated cart data
        $cartData = getCartData($cartID);
        
        // Update cart count in session
        $_SESSION['cart_count'] = $cartData['total_items'];
        
        ob_clean(); // Clear any output before JSON
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $cartData
        ]);
        
    } catch (Exception $e) {
        error_log("Cart AJAX error: " . $e->getMessage());
        error_log("Cart AJAX error details: " . print_r([
            'action' => $action,
            'prodID' => $prodID,
            'qty' => $qty,
            'userID' => $userID,
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ], true));
        
        ob_clean(); // Clear any output before JSON
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    exit();
}

// Handle regular form submissions (fallback)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $prodID = trim($_POST['prodID'] ?? '');
    $qty = intval($_POST['qty'] ?? 1);
    
    try {
        // Get user's cart
        $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
        $cartStmt = $_db->prepare($cartQuery);
        $cartStmt->execute([$userID]);
        $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$cart) {
            throw new Exception("Cart not found");
        }
        
        $cartID = $cart['cartID'];
        
        switch ($action) {
            case 'update':
                if (!empty($prodID) && $qty > 0) {
                    // Check stock availability
                    $stockQuery = "SELECT qty FROM product WHERE prodID = ? AND (status IS NULL OR status != 'removed')";
                    $stockStmt = $_db->prepare($stockQuery);
                    $stockStmt->execute([$prodID]);
                    $stock = $stockStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$stock) {
                        throw new Exception("Product not found or unavailable");
                    }
                    
                    if ($qty > $stock['qty']) {
                        throw new Exception("Insufficient stock. Available: " . $stock['qty'] . " items");
                    }
                    
                    // Update quantity
                    $updateQuery = "UPDATE cart_items SET qty = ? WHERE cartID = ? AND prodID = ?";
                    $updateStmt = $_db->prepare($updateQuery);
                    $updateStmt->execute([$qty, $cartID, $prodID]);
                    
                    if ($updateStmt->rowCount() > 0) {
                        $_SESSION['success'] = "Quantity updated successfully";
                    } else {
                        throw new Exception("Item not found in cart");
                    }
                }
                break;
                
            case 'remove':
                if (!empty($prodID)) {
                    $removeQuery = "DELETE FROM cart_items WHERE cartID = ? AND prodID = ?";
                    $removeStmt = $_db->prepare($removeQuery);
                    $removeStmt->execute([$cartID, $prodID]);
                    
                    if ($removeStmt->rowCount() > 0) {
                        $_SESSION['success'] = "Item removed from cart";
                    } else {
                        throw new Exception("Item not found in cart");
                    }
                }
                break;
                
            case 'clear':
                $clearQuery = "DELETE FROM cart_items WHERE cartID = ?";
                $clearStmt = $_db->prepare($clearQuery);
                $clearStmt->execute([$cartID]);
                $_SESSION['success'] = "Cart cleared successfully";
                break;
        }
        
        // Update cart count in session
        $cartCountQuery = "SELECT SUM(qty) as total FROM cart_items WHERE cartID = ?";
        $cartCountStmt = $_db->prepare($cartCountQuery);
        $cartCountStmt->execute([$cartID]);
        $cartCount = $cartCountStmt->fetch(PDO::FETCH_ASSOC);
        $_SESSION['cart_count'] = $cartCount['total'] ?? 0;
        
    } catch (Exception $e) {
        error_log("Cart action error: " . $e->getMessage());
        $_SESSION['error'] = $e->getMessage();
    }
    
    // Redirect to prevent form resubmission
    header('Location: cart_page.php');
    exit();
}

function getCartData($cartID) {
    global $_db;
    
    try {
        // Get cart items with product details
        $itemsQuery = "SELECT ci.*, p.name, p.price, p.qty as stock, p.image1, p.color, p.material
                      FROM cart_items ci
                      JOIN product p ON ci.prodID = p.prodID
                      WHERE ci.cartID = ? AND (p.status IS NULL OR p.status != 'removed')";
        $itemsStmt = $_db->prepare($itemsQuery);
        $itemsStmt->execute([$cartID]);
        $cart_items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $subtotal = 0;
        $total_items = 0;
        
        // Calculate totals
        foreach ($cart_items as $item) {
            $item_subtotal = ($item['price'] ?? 0) * ($item['qty'] ?? 0);
            $subtotal += $item_subtotal;
            $total_items += ($item['qty'] ?? 0);
        }
        
        $shipping_fee = 8.00;
        $total = $subtotal + $shipping_fee;
        
        return [
            'items' => $cart_items,
            'subtotal' => $subtotal,
            'shipping_fee' => $shipping_fee,
            'total' => $total,
            'total_items' => $total_items
        ];
        
    } catch (Exception $e) {
        error_log("Get cart data error: " . $e->getMessage());
        return [
            'items' => [],
            'subtotal' => 0,
            'shipping_fee' => 8.00,
            'total' => 8.00,
            'total_items' => 0
        ];
    }
}

// Get cart items
try {
    // First, let's check if the user has a cart
    $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
    $cartStmt = $_db->prepare($cartQuery);
    $cartStmt->execute([$userID]);
    $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
    
    $cart_items = [];
    $subtotal = 0;
    $total_items = 0;
    
    if ($cart) {
        $cartID = $cart['cartID'];
        
        // Debug: Check if cart_items table exists and has data
        $debugQuery = "SELECT COUNT(*) as count FROM cart_items WHERE cartID = ?";
        $debugStmt = $_db->prepare($debugQuery);
        $debugStmt->execute([$cartID]);
        $debugResult = $debugStmt->fetch(PDO::FETCH_ASSOC);
        error_log("Cart items count for cartID $cartID: " . $debugResult['count']);
        
        // Get cart items with product details - simplified query first
        $itemsQuery = "SELECT ci.*, p.name, p.price, p.qty as stock, p.image1, p.color, p.material
                      FROM cart_items ci
                      JOIN product p ON ci.prodID = p.prodID
                      WHERE ci.cartID = ? AND (p.status IS NULL OR p.status != 'removed')";
        $itemsStmt = $_db->prepare($itemsQuery);
        $itemsStmt->execute([$cartID]);
        $cart_items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("Cart items fetched: " . count($cart_items));
        
        // Calculate totals
        foreach ($cart_items as $item) {
            $item_subtotal = ($item['price'] ?? 0) * ($item['qty'] ?? 0);
            $subtotal += $item_subtotal;
            $total_items += ($item['qty'] ?? 0);
        }
    } else {
        error_log("No cart found for userID: $userID");
    }
    
} catch (Exception $e) {
    error_log("Cart fetch error: " . $e->getMessage());
    error_log("Cart fetch error details: " . print_r($e, true));
    $_SESSION['error'] = "Failed to load cart. Please try again. Error: " . $e->getMessage();
    $cart_items = [];
    $subtotal = 0;
    $total_items = 0;
}

$shipping_fee = 8.00;
$total = $subtotal + $shipping_fee;
?>

<?php include '../header.php'; ?>

<link rel="stylesheet" href="../css/cart.css">
<script src="../js/cart.js" defer></script>

<main class="cart-main">
    <div class="cart-container">
        <div class="cart-header">
            <h1>Shopping Cart</h1>
            <div class="cart-summary">
                <span class="item-count"><?= $total_items ?> item<?= $total_items != 1 ? 's' : '' ?></span>
                <!-- Debug buttons - remove in production -->
                <button onclick="testAjax()" style="margin-left: 10px; padding: 5px 10px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">Test AJAX</button>
                <button onclick="testCartUpdate()" style="margin-left: 5px; padding: 5px 10px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">Test Cart</button>
                <button onclick="window.open('debug_cart_items.php', '_blank')" style="margin-left: 5px; padding: 5px 10px; background: #ffc107; color: black; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">Debug Items</button>
            </div>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($_SESSION['success']) ?>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($_SESSION['error']) ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <div class="empty-cart-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <h2>Your cart is empty</h2>
                <p>Looks like you haven't added any items to your cart yet.</p>
                <a href="../userProduct/productList.php" class="btn btn-primary">
                    <i class="fas fa-shopping-bag"></i>
                    Start Shopping
                </a>
            </div>
        <?php else: ?>
            <div class="cart-content">
                <div class="cart-controls">
                    <div class="select-all-container">
                        <input type="checkbox" id="select-all" class="select-all-checkbox">
                        <label for="select-all" class="select-all-label">
                            <span class="checkmark"></span>
                            Select All Items
                        </label>
                    </div>
                    <div class="selected-info">
                        <span id="selected-count">0</span> item(s) selected
                    </div>
                </div>
                
                <div class="cart-items-section">
                    <div class="cart-items">
                    <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item" data-prod-id="<?= $item['prodID'] ?>">
                            <div class="item-selection">
                                <input type="checkbox" 
                                       class="item-checkbox" 
                                       id="item-<?= $item['prodID'] ?>" 
                                       data-prod-id="<?= $item['prodID'] ?>"
                                       data-price="<?= $item['price'] ?? 0 ?>"
                                       data-qty="<?= $item['qty'] ?? 1 ?>"
                                       >
                                <label for="item-<?= $item['prodID'] ?>" class="checkbox-label">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            
                            <div class="item-image">
                                <?php if (!empty($item['image1'])): ?>
                                    <img src="data:image/jpeg;base64,<?= base64_encode($item['image1']) ?>" 
                                         alt="<?= htmlspecialchars($item['name']) ?>"
                                         onclick="window.location.href='../userProduct/product_detail.php?prodID=<?= $item['prodID'] ?>'">
                                <?php else: ?>
                                    <img src="../images/placeholder.jpg" 
                                         alt="<?= htmlspecialchars($item['name']) ?>"
                                         onclick="window.location.href='../userProduct/product_detail.php?prodID=<?= $item['prodID'] ?>'">
                                <?php endif; ?>
                            </div>
                            
                            <div class="item-details">
                                <h3 class="item-name">
                                    <a href="../userProduct/product_detail.php?prodID=<?= $item['prodID'] ?>">
                                        <?= htmlspecialchars($item['name'] ?? 'Unknown Product') ?>
                                    </a>
                                </h3>
                                <p class="item-category"><?= htmlspecialchars($item['category_name'] ?? 'Uncategorized') ?></p>
                                
                                <?php if (!empty($item['color'])): ?>
                                    <p class="item-color"><strong>Color:</strong> <?= htmlspecialchars($item['color']) ?></p>
                                <?php endif; ?>
                                
                                <?php if (!empty($item['material'])): ?>
                                    <p class="item-material"><strong>Material:</strong> <?= htmlspecialchars($item['material']) ?></p>
                                <?php endif; ?>
                                
                                <div class="item-stock">
                                    <?php if ($item['stock'] > 0): ?>
                                        <?php if ($item['stock'] < 10): ?>
                                            <span class="stock-status low-stock">
                                                <i class="fas fa-exclamation-triangle"></i>
                                                Low Stock - Only <?= $item['stock'] ?> available
                                            </span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="stock-status out-of-stock">
                                            <i class="fas fa-times-circle"></i>
                                            Out of Stock
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="item-quantity">
                                <label for="qty-<?= $item['prodID'] ?>">Quantity:</label>
                                <div class="quantity-controls">
                                    <button type="button" class="qty-btn qty-decrease" 
                                            data-prod-id="<?= $item['prodID'] ?>" 
                                            data-max="<?= $item['stock'] ?>"
                                            title="Decrease quantity">−</button>
                                    <input type="number" 
                                           id="qty-<?= $item['prodID'] ?>" 
                                           class="qty-input" 
                                           value="<?= $item['qty'] ?? 1 ?>" 
                                           min="1" 
                                           max="<?= $item['stock'] ?? 999 ?>"
                                           data-prod-id="<?= $item['prodID'] ?>"
                                           data-original-value="<?= $item['qty'] ?? 1 ?>"
                                           data-max-stock="<?= $item['stock'] ?? 999 ?>"
                                           title="Enter quantity (max: <?= $item['stock'] ?? 999 ?>)"
                                           oninput="validateQuantity(this)">
                                    <button type="button" class="qty-btn qty-increase" 
                                            data-prod-id="<?= $item['prodID'] ?>" 
                                            data-max="<?= $item['stock'] ?>"
                                            title="Increase quantity">+</button>
                                </div>
                                <div class="quantity-loading" style="display: none;">
                                    <i class="fas fa-spinner fa-spin"></i>
                                </div>
                            </div>
                            
                            <div class="item-price">
                                <div class="price-per-unit">
                                    <?= money($item['price'] ?? 0) ?> each
                                </div>
                                <div class="price-total">
                                    <?= money(($item['price'] ?? 0) * ($item['qty'] ?? 0)) ?>
                                </div>
                            </div>
                            
                            <div class="item-actions">
                                <button type="button" class="btn-remove" 
                                        data-prod-id="<?= $item['prodID'] ?>"
                                        title="Remove from cart">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    
                    <div class="cart-summary-section">
                    <div class="summary-card">
                        <h3>Order Summary</h3>
                        
                        <div class="summary-row">
                            <span>Subtotal (<span id="summary-item-count">0</span> item<span id="summary-item-plural">s</span>)</span>
                            <span id="summary-subtotal">RM 0.00</span>
                        </div>
                        
                        <div class="summary-row">
                            <span>Shipping</span>
                            <span id="summary-shipping"><?= money($shipping_fee) ?></span>
                        </div>
                        
                        <div class="summary-row total">
                            <span>Total</span>
                            <span id="summary-total">RM 0.00</span>
                        </div>
                        
                        <div class="summary-actions">
                            <a href="../userProduct/productList.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i>
                                Continue Shopping
                            </a>
                            
                            <button type="button" class="btn btn-danger" id="clear-cart-btn">
                                <i class="fas fa-trash"></i>
                                Clear Cart
                            </button>
                            
                            <button type="button" class="btn btn-primary btn-checkout disabled" id="checkout-selected">
                                <i class="fas fa-credit-card"></i>
                                Proceed to Checkout (<span id="checkout-count">0</span> items)
                            </button>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<!-- Hidden forms for cart actions -->
<form id="update-form" method="POST" style="display: none;">
    <input type="hidden" name="action" value="update">
    <input type="hidden" name="prodID" id="update-prod-id">
    <input type="hidden" name="qty" id="update-qty">
</form>

<form id="remove-form" method="POST" style="display: none;">
    <input type="hidden" name="action" value="remove">
    <input type="hidden" name="prodID" id="remove-prod-id">
</form>

<form id="clear-form" method="POST" style="display: none;">
    <input type="hidden" name="action" value="clear">
</form>

<form id="checkout-form" method="POST" action="checkout.php" style="display: none;">
    <input type="hidden" name="selected_items" id="selected-items">
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Store original values for quantity inputs
    document.querySelectorAll('.qty-input').forEach(input => {
        input.dataset.originalValue = input.value;
    });
    
    // Quantity controls
    document.querySelectorAll('.qty-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const prodID = this.dataset.prodId;
            const input = document.getElementById(`qty-${prodID}`);
            const max = parseInt(this.dataset.max);
            let newQty = parseInt(input.value);
            
            if (this.classList.contains('qty-increase')) {
                newQty = Math.min(newQty + 1, max);
                if (newQty === max && newQty > parseInt(input.value)) {
                    showCartNotification(`Maximum quantity is ${max} items`, 'warning');
                }
            } else if (this.classList.contains('qty-decrease')) {
                newQty = Math.max(newQty - 1, 1);
            }
            
            if (newQty !== parseInt(input.value)) {
                input.value = newQty;
                input.dataset.originalValue = input.value;
                updateCartItem(prodID, newQty);
            }
        });
    });
    
    // Quantity input change with debouncing
    let quantityTimeout;
    document.querySelectorAll('.qty-input').forEach(input => {
        input.addEventListener('input', function() {
            clearTimeout(quantityTimeout);
            quantityTimeout = setTimeout(() => {
                const prodID = this.dataset.prodId;
                const max = parseInt(this.dataset.max);
                let qty = parseInt(this.value);
                
                if (isNaN(qty) || qty < 1) qty = 1;
                if (qty > max) qty = max;
                
                this.value = qty;
                this.dataset.originalValue = qty;
                updateCartItem(prodID, qty);
            }, 500); // 500ms delay
        });
        
        input.addEventListener('change', function() {
            clearTimeout(quantityTimeout);
            const prodID = this.dataset.prodId;
            const max = parseInt(this.dataset.max);
            let qty = parseInt(this.value);
            
            if (isNaN(qty) || qty < 1) qty = 1;
            if (qty > max) qty = max;
            
            this.value = qty;
            this.dataset.originalValue = qty;
            updateCartItem(prodID, qty);
        });
    });
    
    // Remove item buttons
    document.querySelectorAll('.btn-remove').forEach(btn => {
        btn.addEventListener('click', function() {
            const prodID = this.dataset.prodId;
            if (confirm('Are you sure you want to remove this item from your cart?')) {
                removeCartItem(prodID);
            }
        });
    });
    
    // Clear cart button
    document.getElementById('clear-cart-btn').addEventListener('click', function() {
        if (confirm('Are you sure you want to clear your entire cart?')) {
            clearCart();
        }
    });
    
    // Enhanced updateCartItem function with loading states
    function updateCartItem(prodID, qty) {
        const cartItem = document.querySelector(`[data-prod-id="${prodID}"]`);
        const qtyInput = document.getElementById(`qty-${prodID}`);
        const loadingSpinner = cartItem.querySelector('.quantity-loading');
        
        // Show loading state
        if (cartItem) {
            cartItem.classList.add('updating');
        }
        if (loadingSpinner) {
            loadingSpinner.style.display = 'block';
        }
        if (qtyInput) {
            qtyInput.disabled = true;
        }
        
        const formData = new FormData();
        formData.append('ajax', '1');
        formData.append('action', 'update');
        formData.append('prodID', prodID);
        formData.append('qty', qty);
        
        console.log('Sending AJAX request:', {
            prodID: prodID,
            qty: qty,
            action: 'update',
            prodIDType: typeof prodID,
            prodIDValue: prodID
        });
        
        fetch('cart_page.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            console.log('Response received:', {
                status: response.status,
                statusText: response.statusText,
                ok: response.ok
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            // First get the response as text to check if it's valid JSON
            return response.text().then(text => {
                console.log('Raw response:', text);
                
                // Check if response is empty
                if (!text || text.trim() === '') {
                    throw new Error('Server returned empty response');
                }
                
                // Check if it looks like HTML (error page)
                if (text.includes('<!DOCTYPE') || text.includes('<html')) {
                    throw new Error('Server returned HTML error page instead of JSON');
                }
                
                // Try to parse as JSON
                try {
                    return JSON.parse(text);
                } catch (e) {
                    console.error('JSON parse error:', e);
                    console.error('Response text:', text);
                    throw new Error('Server returned invalid JSON response');
                }
            });
        })
        .then(data => {
            console.log('Response data:', data);
            
            if (data.success) {
                // Update cart display without page refresh
                updateCartDisplay(data.data);
                showCartNotification(data.message, 'success');
                
                // Update price display for this item
                updateItemPrice(prodID, qty, data.data.items);
            } else {
                console.log('Server returned error:', data.message);
                showCartNotification(data.message, 'error');
                // Revert quantity input if update failed
                if (qtyInput) {
                    qtyInput.value = qtyInput.dataset.originalValue || 1;
                }
            }
        })
        .catch(error => {
            console.error('Update cart error:', error);
            console.error('Error details:', {
                message: error.message,
                stack: error.stack,
                prodID: prodID,
                qty: qty
            });
            
            let errorMessage = 'Failed to update cart item';
            if (error.message.includes('HTTP error')) {
                errorMessage = 'Server error occurred. Please try again.';
            } else if (error.message.includes('JSON')) {
                errorMessage = 'Invalid response from server. Please refresh and try again.';
            } else if (error.message.includes('fetch')) {
                errorMessage = 'Network error. Please check your connection.';
            }
            
            showCartNotification(errorMessage, 'error');
            // Revert quantity input if update failed
            if (qtyInput) {
                qtyInput.value = qtyInput.dataset.originalValue || 1;
            }
        })
        .finally(() => {
            // Remove loading state
            if (cartItem) {
                cartItem.classList.remove('updating');
            }
            if (loadingSpinner) {
                loadingSpinner.style.display = 'none';
            }
            if (qtyInput) {
                qtyInput.disabled = false;
            }
        });
    }
    
    // Function to update individual item price
    function updateItemPrice(prodID, qty, items) {
        const item = items.find(item => item.prodID == prodID);
        if (item) {
            const priceTotal = document.querySelector(`[data-prod-id="${prodID}"] .price-total`);
            if (priceTotal) {
                priceTotal.textContent = formatMoney(item.price * qty);
            }
        }
    }
    
    // Function to update cart display
    function updateCartDisplay(cartData) {
        if (!cartData) return;
        
        // Update cart count
        updateCartCountDisplay(cartData.total_items);
        
        // Update item count in header
        const itemCountElement = document.querySelector('.item-count');
        if (itemCountElement) {
            itemCountElement.textContent = cartData.total_items;
        }
        
        // Update order summary
        updateOrderSummaryFromData(cartData);
        
        // If cart is empty, show empty cart message
        if (cartData.items.length === 0) {
            showEmptyCart();
        }
    }
    
    // Function to update order summary from cart data
    function updateOrderSummaryFromData(cartData) {
        const summaryItemCount = document.getElementById('summary-item-count');
        const summaryItemPlural = document.getElementById('summary-item-plural');
        const summarySubtotal = document.getElementById('summary-subtotal');
        const summaryTotal = document.getElementById('summary-total');
        
        if (summaryItemCount) {
            summaryItemCount.textContent = cartData.total_items;
            summaryItemPlural.textContent = cartData.total_items !== 1 ? 's' : '';
        }
        
        if (summarySubtotal) {
            summarySubtotal.textContent = formatMoney(cartData.subtotal);
        }
        
        if (summaryTotal) {
            summaryTotal.textContent = formatMoney(cartData.total);
        }
    }
    
    // Function to show empty cart message
    function showEmptyCart() {
        const cartContent = document.querySelector('.cart-content');
        if (cartContent) {
            cartContent.innerHTML = `
                <div class="empty-cart">
                    <div class="empty-cart-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <h2>Your cart is empty</h2>
                    <p>Looks like you haven't added any items to your cart yet.</p>
                    <a href="../userProduct/productList.php" class="btn btn-primary">
                        <i class="fas fa-shopping-bag"></i>
                        Start Shopping
                    </a>
                </div>
            `;
        }
    }
    
    // Function to format money for display
    function formatMoney(amount) {
        return 'RM ' + amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
    
    // Function to show cart notification
    function showCartNotification(message, type = 'success') {
        // Remove existing notifications
        const existingNotifications = document.querySelectorAll('.cart-notification');
        existingNotifications.forEach(notification => notification.remove());
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `cart-notification ${type}`;
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Remove after 4 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }
    
    // Test AJAX function
    window.testAjax = function() {
        console.log('Testing AJAX...');
        
        const formData = new FormData();
        formData.append('test', '1');
        
        fetch('test_ajax.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            console.log('Test response status:', response.status);
            return response.text();
        })
        .then(text => {
            console.log('Test raw response:', text);
            try {
                const data = JSON.parse(text);
                console.log('Test parsed data:', data);
                showCartNotification('AJAX test successful!', 'success');
            } catch (e) {
                console.error('Test JSON parse error:', e);
                showCartNotification('AJAX test failed - invalid JSON', 'error');
            }
        })
        .catch(error => {
            console.error('Test fetch error:', error);
            showCartNotification('AJAX test failed - ' + error.message, 'error');
        });
    };
    
    // Test cart update function
    window.testCartUpdate = function() {
        console.log('Testing cart update...');
        
        const formData = new FormData();
        formData.append('test_cart', '1');
        
        fetch('test_cart_update.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            console.log('Cart test response status:', response.status);
            return response.text();
        })
        .then(text => {
            console.log('Cart test raw response:', text);
            try {
                const data = JSON.parse(text);
                console.log('Cart test parsed data:', data);
                
                if (data.success) {
                    showCartNotification('Cart test successful! Found ' + (data.data.item ? '1 item' : '0 items'), 'success');
                    
                    // If we have an item, test actual update with a safe quantity
                    if (data.data.item) {
                        console.log('Testing actual cart update with item:', data.data.item.prodID);
                        // Test with current quantity (should always work)
                        testActualUpdate(data.data.item.prodID, data.data.item.qty);
                    }
                } else {
                    showCartNotification('Cart test failed: ' + data.message, 'error');
                }
            } catch (e) {
                console.error('Cart test JSON parse error:', e);
                showCartNotification('Cart test failed - invalid JSON', 'error');
            }
        })
        .catch(error => {
            console.error('Cart test fetch error:', error);
            showCartNotification('Cart test failed - ' + error.message, 'error');
        });
    };
    
    // Validate quantity input
    window.validateQuantity = function(input) {
        const maxStock = parseInt(input.dataset.maxStock) || 999;
        const currentValue = parseInt(input.value) || 1;
        
        if (currentValue > maxStock) {
            input.value = maxStock;
            showCartNotification(`Maximum quantity is ${maxStock} items`, 'warning');
        } else if (currentValue < 1) {
            input.value = 1;
        }
    };
    
    // Test actual cart update
    function testActualUpdate(prodID, qty) {
        console.log('Testing actual update for prodID:', prodID, 'qty:', qty);
        
        const formData = new FormData();
        formData.append('ajax', '1');
        formData.append('action', 'update');
        formData.append('prodID', prodID);
        formData.append('qty', qty);
        
        fetch('cart_page.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            console.log('Actual update response status:', response.status);
            return response.text();
        })
        .then(text => {
            console.log('Actual update raw response:', text);
            try {
                const data = JSON.parse(text);
                console.log('Actual update parsed data:', data);
                
                if (data.success) {
                    showCartNotification('Actual update successful!', 'success');
                } else {
                    showCartNotification('Actual update failed: ' + data.message, 'error');
                }
            } catch (e) {
                console.error('Actual update JSON parse error:', e);
                showCartNotification('Actual update failed - invalid JSON', 'error');
            }
        })
        .catch(error => {
            console.error('Actual update fetch error:', error);
            showCartNotification('Actual update failed - ' + error.message, 'error');
        });
    }
});
</script>

<?php include '../footer.php'; ?>
