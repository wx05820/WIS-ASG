<?php
// Simple test script to debug cart AJAX issues
require_once '../_base.php';

// Check if user is logged in
if (!isLoggedIn()) {
    echo "User not logged in";
    exit();
}

$userID = $_SESSION['user_id'];
echo "User ID: $userID<br>";

// Test database connection
try {
    $testQuery = "SELECT cartID FROM cart WHERE userID = ?";
    $testStmt = $_db->prepare($testQuery);
    $testStmt->execute([$userID]);
    $cart = $testStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($cart) {
        echo "Cart found: " . $cart['cartID'] . "<br>";
        
        // Test cart items
        $itemsQuery = "SELECT ci.*, p.name FROM cart_items ci JOIN product p ON ci.prodID = p.prodID WHERE ci.cartID = ?";
        $itemsStmt = $_db->prepare($itemsQuery);
        $itemsStmt->execute([$cart['cartID']]);
        $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "Cart items count: " . count($items) . "<br>";
        foreach ($items as $item) {
            echo "Item: " . $item['name'] . " (ID: " . $item['prodID'] . ", Qty: " . $item['qty'] . ")<br>";
        }
    } else {
        echo "No cart found for user<br>";
    }
} catch (Exception $e) {
    echo "Database error: " . $e->getMessage();
}

// Test AJAX request simulation
echo "<br><br>Testing AJAX request...<br>";

// Simulate POST data
$_POST['ajax'] = '1';
$_POST['action'] = 'update';
$_POST['prodID'] = '1'; // Replace with actual product ID from your cart
$_POST['qty'] = '2';

echo "Simulated POST data:<br>";
echo "ajax: " . ($_POST['ajax'] ?? 'not set') . "<br>";
echo "action: " . ($_POST['action'] ?? 'not set') . "<br>";
echo "prodID: " . ($_POST['prodID'] ?? 'not set') . "<br>";
echo "qty: " . ($_POST['qty'] ?? 'not set') . "<br>";
?>

