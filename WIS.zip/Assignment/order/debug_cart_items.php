<?php
// Debug script to show cart items
require_once '../_base.php';

// Check if user is logged in
if (!isLoggedIn()) {
    echo "User not logged in";
    exit();
}

$userID = $_SESSION['user_id'];

try {
    // Get user's cart
    $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
    $cartStmt = $_db->prepare($cartQuery);
    $cartStmt->execute([$userID]);
    $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cart) {
        echo "No cart found for user $userID";
        exit();
    }
    
    $cartID = $cart['cartID'];
    echo "Cart ID: $cartID<br><br>";
    
    // Get cart items with product details
    $itemsQuery = "SELECT ci.prodID, ci.qty, p.name, p.price 
                   FROM cart_items ci 
                   JOIN product p ON ci.prodID = p.prodID 
                   WHERE ci.cartID = ?";
    $itemsStmt = $_db->prepare($itemsQuery);
    $itemsStmt->execute([$cartID]);
    $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Cart Items (" . count($items) . "):<br>";
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Type</th></tr>";
    
    foreach ($items as $item) {
        echo "<tr>";
        echo "<td>" . $item['prodID'] . "</td>";
        echo "<td>" . htmlspecialchars($item['name']) . "</td>";
        echo "<td>" . $item['qty'] . "</td>";
        echo "<td>RM " . number_format($item['price'], 2) . "</td>";
        echo "<td>" . gettype($item['prodID']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Show raw data
    echo "<br>Raw data:<br>";
    echo "<pre>" . print_r($items, true) . "</pre>";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

