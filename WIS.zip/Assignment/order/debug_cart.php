<?php
// Debug script to test cart AJAX functionality
require_once '../_base.php';

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

$userID = $_SESSION['user_id'];

// Test the cart AJAX endpoint
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test'])) {
    header('Content-Type: application/json');
    
    try {
        // Get user's cart
        $cartQuery = "SELECT cartID FROM cart WHERE userID = ?";
        $cartStmt = $_db->prepare($cartQuery);
        $cartStmt->execute([$userID]);
        $cart = $cartStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$cart) {
            echo json_encode([
                'success' => false,
                'message' => 'Cart not found'
            ]);
            exit();
        }
        
        $cartID = $cart['cartID'];
        
        // Get cart items
        $itemsQuery = "SELECT ci.*, p.name, p.price FROM cart_items ci JOIN product p ON ci.prodID = p.prodID WHERE ci.cartID = ?";
        $itemsStmt = $_db->prepare($itemsQuery);
        $itemsStmt->execute([$cartID]);
        $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'message' => 'Cart data retrieved successfully',
            'data' => [
                'cartID' => $cartID,
                'items' => $items,
                'total_items' => count($items)
            ]
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error: ' . $e->getMessage()
        ]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cart Debug</title>
</head>
<body>
    <h1>Cart Debug Test</h1>
    <p>User ID: <?= $userID ?></p>
    
    <button onclick="testCart()">Test Cart AJAX</button>
    <div id="result"></div>
    
    <script>
    function testCart() {
        const formData = new FormData();
        formData.append('test', '1');
        
        fetch('debug_cart.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            console.log('Response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('Response data:', data);
            document.getElementById('result').innerHTML = '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('result').innerHTML = '<p style="color: red;">Error: ' + error.message + '</p>';
        });
    }
    </script>
</body>
</html>

